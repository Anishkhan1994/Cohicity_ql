package com.onlinebanking;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


import java.sql.Timestamp;

/**
 * Example: Synthetic Monitoring with Network Speed Capture
 * 
 * This class demonstrates how to integrate NetworkSpeedMonitor
 * with your existing Selenium automation and database logging.
 */
public class SyntheticMonitoringWithSpeed {
    
    private ChromeDriver driver;
    private NetworkSpeedMonitor speedMonitor;
    private DBHelper dbHelper;
    String sessionId = DriverContext.SESSION_ID;

    public static void main(String[] args) {
        SyntheticMonitoringWithSpeed monitor = new SyntheticMonitoringWithSpeed();
        monitor.runTest();
    }
    
    public void runTest() {
        try {
            setup();
            
            // Test Case 1: Login Flow with Speed Monitoring
            testLoginFlow();
            
            // // Test Case 2: Dashboard Load with Speed Monitoring
            // testDashboardLoad();
            
        } catch (Exception e) {
            System.err.println("❌ Test execution failed: " + e.getMessage());
            e.printStackTrace();
        } finally {
            tearDown();
        }
    }
    
    /**
     * Setup: Initialize WebDriver, Speed Monitor, and Database
     */
    private void setup() {
        System.out.println("🔧 Setting up test environment...");
        
        // Setup ChromeDriver
        WebDriverManager.chromedriver().setup();
        
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        options.addArguments("--disable-blink-features=AutomationControlled");
        options.addArguments("--start-maximized");
        // options.addArguments("--headless"); // Uncomment for headless mode
        
        driver = new ChromeDriver(options);
        
        // Initialize Network Speed Monitor
        speedMonitor = new NetworkSpeedMonitor();
        speedMonitor.initialize(driver);
        
        // Connect to Database
        dbHelper = new DBHelper();
        dbHelper.connect();
        
        System.out.println("✅ Setup complete\n");
    }
    
    /**
     * Test Case: Login Flow with Network Speed Monitoring
     */
    private void testLoginFlow() {
        String testName = "Login Flow Test";
        String url = "http://192.168.100.214:8080/OnlineBank/";
        Timestamp startTime = new Timestamp(System.currentTimeMillis());
        
        System.out.println("🧪 Running: " + testName);
        
        try {
            // Start network monitoring
            speedMonitor.startMonitoring();
            
            // Navigate to login page
            driver.get(url);
            
            // Perform login actions
            WebElement loginButton = driver.findElement(By.xpath("/html/body/main/section[1]/div/div/div/a[2]"));
                loginButton.click();
            driver.findElement(By.xpath("//*[@id=\"phoneNumber\"]")).sendKeys("9878786568");
            driver.findElement(By.id("//*[@id=\"password\"]")).sendKeys("123");
            driver.findElement(By.id("//*[@id=\"login-form\"]/button")).click();
            
            // Wait for page load
            Thread.sleep(3000);
            
            // Stop monitoring and get metrics
            NetworkSpeedMonitor.NetworkMetrics metrics = speedMonitor.stopMonitoring();
            
            // Display metrics
            metrics.display();
            
            // Calculate response time
            Timestamp endTime = new Timestamp(System.currentTimeMillis());
            long responseTime = endTime.getTime() - startTime.getTime();
            
            // Save to database
            saveMetricsToDatabase(testName, url, metrics, startTime, endTime, responseTime, "PASS", 200);
            
        } catch (Exception e) {
            handleTestFailure(testName, url, startTime, e);
        }
    }
    
    /**
     * Test Case: Dashboard Load with Network Speed Monitoring
     */
    // private void testDashboardLoad() {
    //     String testName = "Dashboard Load Test";
    //     String url = "https://example.com/dashboard";
    //     Timestamp startTime = new Timestamp(System.currentTimeMillis());
        
    //     System.out.println("🧪 Running: " + testName);
        
    //     try {
    //         // Start network monitoring
    //         speedMonitor.startMonitoring();
            
    //         // Navigate to dashboard
    //         driver.get(url);
            
    //         // Wait for dynamic content
    //         Thread.sleep(5000);
            
    //         // Stop monitoring and get metrics
    //         NetworkSpeedMonitor.NetworkMetrics metrics = speedMonitor.stopMonitoring();
            
    //         // Display metrics
    //         metrics.display();
            
    //         // Calculate response time
    //         Timestamp endTime = new Timestamp(System.currentTimeMillis());
    //         long responseTime = endTime.getTime() - startTime.getTime();
            
    //         // Save to database
    //         saveMetricsToDatabase(testName, url, metrics, startTime, endTime, responseTime, "PASS", 200);
            
    //     } catch (Exception e) {
    //         handleTestFailure(testName, url, startTime, e);
    //     }
    // }
    
    /**
     * Save metrics to database (both synthetic log and network speed tables)
     */
    private void saveMetricsToDatabase(String testName,
                                      String url,
                                      NetworkSpeedMonitor.NetworkMetrics metrics,
                                      Timestamp startTime,
                                      Timestamp endTime,
                                      long responseTime,
                                      String status,
                                      int responseCode) {
        
        // Insert into synthetic log table
        dbHelper.insertLog(DriverContext.SESSION_ID,
            testName,
            startTime,
            endTime,
            responseTime,
            status,
            "",  // No error
            responseCode
        );
        
        // Insert into network speed metrics table
        dbHelper.insertNetworkSpeed(DriverContext.SESSION_ID,
            testName,
            url,
            metrics.downloadSpeedMbps,
            metrics.uploadSpeedMbps,
            metrics.downloadSpeedMBps,
            metrics.uploadSpeedMBps,
            metrics.totalBytesReceived,
            metrics.totalBytesSent,
            metrics.totalRequests,
            metrics.durationSeconds,
            metrics.avgRequestTimeMs,
            metrics.pageLoadTimeMs
        );
    }
    
    /**
     * Handle test failures
     */
    private void handleTestFailure(String testName, String url, Timestamp startTime, Exception e) {
        System.err.println("❌ Test failed: " + testName);
        e.printStackTrace();
        
        Timestamp endTime = new Timestamp(System.currentTimeMillis());
        long responseTime = endTime.getTime() - startTime.getTime();
        
        // Log failure to database
        dbHelper.insertLog(DriverContext.SESSION_ID,
            testName,
            startTime,
            endTime,
            responseTime,
            "FAIL",
            e.getMessage(),
            500
        );
        
        // Try to get partial network metrics
        try {
            NetworkSpeedMonitor.NetworkMetrics metrics = speedMonitor.getCurrentMetrics();
            dbHelper.insertNetworkSpeed(DriverContext.SESSION_ID,
                testName,
                url,
                metrics.downloadSpeedMbps,
                metrics.uploadSpeedMbps,
                metrics.downloadSpeedMBps,
                metrics.uploadSpeedMBps,
                metrics.totalBytesReceived,
                metrics.totalBytesSent,
                metrics.totalRequests,
                metrics.durationSeconds,
                metrics.avgRequestTimeMs,
                metrics.pageLoadTimeMs
            );
        } catch (Exception ex) {
            System.err.println("⚠️ Could not save partial network metrics");
        }
    }
    
    /**
     * Cleanup resources
     */
    private void tearDown() {
        System.out.println("\n🧹 Cleaning up...");
        
        if (speedMonitor != null) {
            speedMonitor.close();
        }
        
        if (driver != null) {
            driver.quit();
        }
        
        if (dbHelper != null) {
            dbHelper.close();
        }
        
        System.out.println("✅ Cleanup complete");
    }
}

/**
 * Alternative: Simple wrapper for your existing test class
 * 
 * Add this to your existing Selenium test class:
 */
// class YourExistingTestClass {
    
//     private ChromeDriver driver;
//     private NetworkSpeedMonitor speedMonitor;
//     private DBHelper dbHelper;
    
//     public void yourExistingTestMethod() {
//         String testName = "Your Test";
//         String url = "https://your-url.com";
        
//         // Initialize speed monitor (do this once in setup)
//         speedMonitor = new NetworkSpeedMonitor();
//         speedMonitor.initialize(driver);
        
//         // Start monitoring BEFORE navigation
//         speedMonitor.startMonitoring();
        
//         // Your existing Selenium code
//         driver.get(url);
//         // ... your test steps ...
        
//         // Stop monitoring and get metrics
//         NetworkSpeedMonitor.NetworkMetrics metrics = speedMonitor.stopMonitoring();
        
//         // Display and save metrics
//         metrics.display();
        
//         dbHelper.insertNetworkSpeed(
//             testName,
//             url,
//             metrics.downloadSpeedMbps,
//             metrics.uploadSpeedMbps,
//             metrics.downloadSpeedMBps,
//             metrics.uploadSpeedMBps,
//             metrics.totalBytesReceived,
//             metrics.totalBytesSent,
//             metrics.totalRequests,
//             metrics.durationSeconds,
//             metrics.avgRequestTimeMs,
//             metrics.pageLoadTimeMs
//         );
//     }
// }