package com.onlinebanking;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LogTest {
    private static final Logger logger = LogManager.getLogger(LogTest.class);
    public static void main(String[] args) {
        System.setProperty("logs.path", "logs");
        System.setProperty("log4j.configurationFile", "conf/log4j2.xml");
        logger.info("TEST LOG ENTRY");
        System.out.println("Logger class: " + logger.getClass().getName());
    }
}
