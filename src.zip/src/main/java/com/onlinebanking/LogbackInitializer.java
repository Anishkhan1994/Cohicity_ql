package com.onlinebanking;

// import org.apache.logging.log4j.LogManager;
// import org.apache.logging.log4j.Logger;

// public class LogInitializer {
//     private static final Logger logger = LogManager.getLogger(LogInitializer.class);

//     public static void init() {
//         logger.info("Logging initialized.");
//     }
// }


// package com.hitachi.logging;
 

// import org.apache.logging.log4j.LogManager;
// import org.apache.logging.log4j.Logger;

// public class LoggerInitializer {

//     // Initializes Log4j2 using the custom config path
//     public static void init() {
//         System.setProperty("log4j.configurationFile", "conf/log4j2.xml");

//         // Optional: Log a message to verify initialization
//         Logger logger = LogManager.getLogger(LoggerInitializer.class);
//         logger.info("Log4j2 initialized with configuration from conf/log4j2.xml");
//     }

//     // Returns a logger for the given class
//     public static Logger getLogger(Class<?> clazz) {
//         return LogManager.getLogger(clazz);
//     }
// }

 
//  import org.apache.log4j.Logger;
// import org.apache.log4j.xml.DOMConfigurator;
 
// public class LoggerInitializer {
//     public static void init() {
//         DOMConfigurator.configure("./conf/log4j2.xml");
//     }
 
//     public static Logger getLogger(Class<?> clazz) {
//         return Logger.getLogger(clazz);
//     }
// }

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import org.slf4j.LoggerFactory;

import java.io.File;

public final class LogbackInitializer {

    private LogbackInitializer() {}

    public static void init() {
        try {
            File configFile = new File("./conf/logback.xml");

            if (!configFile.exists()) {
                throw new RuntimeException("Logback config not found: " + configFile.getAbsolutePath());
            }

            LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
            context.reset();

            JoranConfigurator configurator = new JoranConfigurator();
            configurator.setContext(context);
            configurator.doConfigure(configFile);

        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize Logback", e);
        }
    }
}
