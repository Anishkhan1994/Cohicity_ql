package com.onlinebanking;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.HasDevTools;
import org.openqa.selenium.devtools.v131.network.Network;
import org.openqa.selenium.devtools.v131.network.model.RequestId;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * NetworkSpeedMonitor - Captures network performance metrics during Selenium tests
 * 
 * Features:
 * - Download/Upload speed in Mbps and MB/s
 * - Total bytes transferred
 * - Request count and average request time
 * - Page load time
 */
public class NetworkSpeedMonitor {
    
    private DevTools devTools;
    private AtomicLong totalBytesReceived = new AtomicLong(0);
    private AtomicLong totalBytesSent = new AtomicLong(0);
    private AtomicInteger requestCount = new AtomicInteger(0);
    private AtomicLong totalRequestTime = new AtomicLong(0);
    private Long startTime;
    private Long pageLoadStartTime;
    private Map<RequestId, Long> requestTimestamps = new HashMap<>();
    
    private boolean isMonitoring = false;
    
    /**
     * Initialize the network monitor with ChromeDriver
     */
    // public void initialize(ChromeDriver driver) {
    //     try {
    //         devTools = driver.getDevTools();
    //         devTools.createSession();
    //         setupNetworkListeners();
    //         System.out.println("Network Speed Monitor initialized");
    //     } catch (Exception e) {
    //         System.err.println("Failed to initialize Network Monitor: " + e.getMessage());
    //         e.printStackTrace();
    //     }
    // }

    public void initialize(WebDriver driver) {
        try {
            if (!(driver instanceof HasDevTools)) {
                throw new IllegalArgumentException("The current browser does not support DevTools.");
            }

            devTools = ((HasDevTools) driver).getDevTools();
            devTools.createSession();
            setupNetworkListeners();

            System.out.println("Network Speed Monitor initialized");
        } catch (Exception e) {
            System.err.println("Failed to initialize Network Monitor: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Setup Chrome DevTools Protocol network listeners
     */
    private void setupNetworkListeners() {
        // Enable network tracking
        devTools.send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty()));
        
        // Listen for request will be sent
        devTools.addListener(Network.requestWillBeSent(), request -> {
            if (!isMonitoring) return;
            
            requestTimestamps.put(request.getRequestId(), System.currentTimeMillis());
            requestCount.incrementAndGet();
            
            // Track uploaded data (POST/PUT data)
            if (request.getRequest().getPostData().isPresent()) {
                long uploadBytes = request.getRequest().getPostData().get().length();
                totalBytesSent.addAndGet(uploadBytes);
            }
            
            // Track request headers size
            int headerSize = request.getRequest().getHeaders().toString().length();
            totalBytesSent.addAndGet(headerSize);
        });
        
        // Listen for data received events
        devTools.addListener(Network.dataReceived(), dataReceived -> {
            if (!isMonitoring) return;
            
            long bytes = dataReceived.getDataLength();
            totalBytesReceived.addAndGet(bytes);
        });
        
        // Listen for response received
        devTools.addListener(Network.responseReceived(), response -> {
            if (!isMonitoring) return;
            
            // Track response headers size
            int headerSize = response.getResponse().getHeaders().toString().length();
            totalBytesReceived.addAndGet(headerSize);
            
            // Track encoded data length if available
            // if (response.getResponse().getEncodedDataLength().isPresent()) {
            //     totalBytesReceived.addAndGet(
            //         response.getResponse().getEncodedDataLength().get().longValue()
            //     );
            // }
            Number encodedDataLength = response.getResponse().getEncodedDataLength();
            if (encodedDataLength != null) {
                totalBytesReceived.addAndGet(encodedDataLength.longValue());
            }
        });
        
        // Listen for loading finished
        devTools.addListener(Network.loadingFinished(), loadingFinished -> {
            if (!isMonitoring) return;
            
            RequestId requestId = loadingFinished.getRequestId();
            
            // Calculate request time
            if (requestTimestamps.containsKey(requestId)) {
                long requestStartTime = requestTimestamps.get(requestId);
                long requestEndTime = System.currentTimeMillis();
                long requestDuration = requestEndTime - requestStartTime;
                totalRequestTime.addAndGet(requestDuration);
                requestTimestamps.remove(requestId);
            }
            
            // Add encoded data length
            // totalBytesReceived.addAndGet(loadingFinished.getEncodedDataLength());
            // Listen for response received
            devTools.addListener(Network.responseReceived(), response -> {
                if (!isMonitoring) return;

                // Track response headers size
                int headerSize = response.getResponse().getHeaders().toString().length();
                totalBytesReceived.addAndGet(headerSize);

                // Track encoded data length if available (handling Number correctly)
                Number encodedDataLength = response.getResponse().getEncodedDataLength();
                if (encodedDataLength != null) {
                    totalBytesReceived.addAndGet(encodedDataLength.longValue());
                }
            });

        });
    }
    
    /**
     * Start monitoring network activity
     */
    public void startMonitoring() {
        resetCounters();
        isMonitoring = true;
        startTime = System.currentTimeMillis();
        pageLoadStartTime = System.currentTimeMillis();
        System.out.println("🚀 Network monitoring started");
    }
    
    /**
     * Stop monitoring and return metrics
     */
    public NetworkMetrics stopMonitoring() {
        isMonitoring = false;
        long endTime = System.currentTimeMillis();
        long pageLoadTime = endTime - pageLoadStartTime;
        
        System.out.println("🛑 Network monitoring stopped");
        
        return calculateMetrics(endTime, pageLoadTime);
    }
    
    /**
     * Get current metrics without stopping monitoring
     */
    public NetworkMetrics getCurrentMetrics() {
        long currentTime = System.currentTimeMillis();
        long pageLoadTime = currentTime - pageLoadStartTime;
        return calculateMetrics(currentTime, pageLoadTime);
    }
    
    /**
     * Calculate network speed metrics
     */
    private NetworkMetrics calculateMetrics(long endTime, long pageLoadTime) {
        if (startTime == null) {
            return new NetworkMetrics();
        }
        
        long durationMs = endTime - startTime;
        double durationSec = durationMs / 1000.0;
        
        if (durationSec <= 0) {
            durationSec = 0.001; // Prevent division by zero
        }
        
        long bytesReceived = totalBytesReceived.get();
        long bytesSent = totalBytesSent.get();
        int requests = requestCount.get();
        long totalReqTime = totalRequestTime.get();
        
        // Calculate speeds in Mbps (Megabits per second)
        double downloadSpeedMbps = (bytesReceived * 8.0) / (durationSec * 1_000_000);
        double uploadSpeedMbps = (bytesSent * 8.0) / (durationSec * 1_000_000);
        
        // Calculate speeds in MB/s (Megabytes per second)
        double downloadSpeedMBps = bytesReceived / (durationSec * 1_000_000);
        double uploadSpeedMBps = bytesSent / (durationSec * 1_000_000);
        
        // Calculate average request time
        double avgRequestTimeMs = requests > 0 ? (double) totalReqTime / requests : 0;
        
        return new NetworkMetrics(
            downloadSpeedMbps,
            uploadSpeedMbps,
            downloadSpeedMBps,
            uploadSpeedMBps,
            bytesReceived,
            bytesSent,
            requests,
            durationSec,
            avgRequestTimeMs,
            pageLoadTime
        );
    }
    
    /**
     * Reset all counters
     */
    private void resetCounters() {
        totalBytesReceived.set(0);
        totalBytesSent.set(0);
        requestCount.set(0);
        totalRequestTime.set(0);
        requestTimestamps.clear();
    }
    
    /**
     * Close DevTools session
     */
    public void close() {
        if (devTools != null) {
            try {
                devTools.close();
                System.out.println("✅ Network Monitor closed");
            } catch (Exception e) {
                System.err.println("⚠️ Error closing Network Monitor: " + e.getMessage());
            }
        }
    }
    
    /**
     * NetworkMetrics - Container for network performance metrics
     */
    public static class NetworkMetrics {
        public double downloadSpeedMbps;
        public double uploadSpeedMbps;
        public double downloadSpeedMBps;
        public double uploadSpeedMBps;
        public long totalBytesReceived;
        public long totalBytesSent;
        public int totalRequests;
        public double durationSeconds;
        public double avgRequestTimeMs;
        public long pageLoadTimeMs;
        
        public NetworkMetrics() {
            // Empty constructor for no data
        }
        
        public NetworkMetrics(double downloadSpeedMbps,
                            double uploadSpeedMbps,
                            double downloadSpeedMBps,
                            double uploadSpeedMBps,
                            long totalBytesReceived,
                            long totalBytesSent,
                            int totalRequests,
                            double durationSeconds,
                            double avgRequestTimeMs,
                            long pageLoadTimeMs) {
            this.downloadSpeedMbps = downloadSpeedMbps;
            this.uploadSpeedMbps = uploadSpeedMbps;
            this.downloadSpeedMBps = downloadSpeedMBps;
            this.uploadSpeedMBps = uploadSpeedMBps;
            this.totalBytesReceived = totalBytesReceived;
            this.totalBytesSent = totalBytesSent;
            this.totalRequests = totalRequests;
            this.durationSeconds = durationSeconds;
            this.avgRequestTimeMs = avgRequestTimeMs;
            this.pageLoadTimeMs = pageLoadTimeMs;
        }
        
        public void display() {
            System.out.println("\n╔════════════════════════════════════════════════════╗");
            System.out.println("║         NETWORK SPEED METRICS                      ║");
            System.out.println("╠════════════════════════════════════════════════════╣");
            System.out.printf("║ Duration:              %.2f seconds               ║%n", durationSeconds);
            System.out.printf("║ Page Load Time:        %d ms                      ║%n", pageLoadTimeMs);
            System.out.println("╠════════════════════════════════════════════════════╣");
            System.out.printf("║ Download Speed:        %.2f Mbps (%.2f MB/s)     ║%n", 
                downloadSpeedMbps, downloadSpeedMBps);
            System.out.printf("║ Upload Speed:          %.2f Mbps (%.2f MB/s)     ║%n", 
                uploadSpeedMbps, uploadSpeedMBps);
            System.out.println("╠════════════════════════════════════════════════════╣");
            System.out.printf("║ Total Downloaded:      %.2f MB                    ║%n", 
                totalBytesReceived / 1_000_000.0);
            System.out.printf("║ Total Uploaded:        %.2f MB                    ║%n", 
                totalBytesSent / 1_000_000.0);
            System.out.printf("║ Total Requests:        %d                          ║%n", totalRequests);
            System.out.printf("║ Avg Request Time:      %.2f ms                    ║%n", avgRequestTimeMs);
            System.out.println("╚════════════════════════════════════════════════════╝\n");
        }
    }
}