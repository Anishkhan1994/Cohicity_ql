package com.onlinebanking;

import org.openqa.selenium.WebDriver;

public class DriverContext {
    public static WebDriver driver;
    public static String SESSION_ID;
}
