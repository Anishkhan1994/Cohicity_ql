//Captch Automation
package com.onlinebanking.ocr;

import java.io.File;

// import org.apache.logging.log4j.LogManager;
// import org.apache.logging.log4j.Logger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

public class CaptchaOCR {
    private static final Logger logger = LoggerFactory.getLogger(CaptchaOCR.class);
    private final String tessDataPath;

    public CaptchaOCR(String tessDataPath) {
        this.tessDataPath = tessDataPath;
    }

    public String readCaptcha(File imageFile) {
        ITesseract instance = new Tesseract();
        instance.setDatapath(tessDataPath);
        instance.setLanguage("eng");

        try {
            String result = instance.doOCR(imageFile);
            result = result.replaceAll("\\s+", "");
            logger.info("Detected CAPTCHA: {}", result);
            return result;
        } catch (TesseractException e) {
            logger.error("OCR failed for file {}: {}", imageFile.getAbsolutePath(), e.getMessage());
            return "";
        }
    }
}